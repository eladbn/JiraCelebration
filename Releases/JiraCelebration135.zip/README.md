# Jira Celebration
Celebrate your achivements with this chrome plugin.
Get a unique image on every task completion and BE HAPPY!


